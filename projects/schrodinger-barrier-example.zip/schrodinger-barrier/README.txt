PHYS 3260 -- Project submission (example / template)
====================================================

This folder is a complete, working example of the kind of project you submit.
Copy its structure for your own project.

What a submission contains
--------------------------
  report.tex        Your write-up in LaTeX (self-contained article; this is
                    what the instructor converts to a web page).
  simulate.py       The Python you wrote to solve the problem and generate
                    every figure and the animation.
  figures/          Every image referenced by report.tex, plus the animation:
                      fig_*.png        static figures
                      anim.gif         the animation shown on the website
                      anim_poster.png  one still frame (used inside the PDF)
  README.txt        This file (optional, but helpful).

How to build it yourself
------------------------
  1. python simulate.py          # regenerates everything in figures/
  2. pdflatex report.tex         # produces report.pdf to check it compiles

What to hand in
---------------
  A single ZIP of this folder, e.g.  schrodinger-barrier.zip
  Make sure report.tex compiles on its own and every \includegraphics path
  points inside figures/.

Requirements checklist
----------------------
  [ ] A title that names the physics and the method.
  [ ] The physics question stated clearly.
  [ ] The mathematical model and the method worked out (real steps, not just
      the final formula).
  [ ] Python that actually produces the data and figures.
  [ ] At least one visualization; an animation is encouraged.
  [ ] A discussion that ties the work back to methods from the course.
  [ ] report.tex compiles and the ZIP contains every figure it needs.
