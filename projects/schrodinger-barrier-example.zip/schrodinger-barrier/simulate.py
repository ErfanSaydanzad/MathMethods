"""
1D time-dependent Schrodinger equation: a Gaussian wave packet scattering off a
rectangular barrier, solved by the split-step Fourier method.

Units: hbar = m = 1.

Run from the project folder:
    python simulate.py

It writes four assets into ./figures/:
    fig_setup.png         initial packet and the barrier
    fig_snapshots.png     |psi|^2 at four times (incident -> reflected+transmitted)
    fig_transmission.png  analytic transmission coefficient T(E) vs energy
    anim.gif              animation of |psi|^2 propagating and scattering
    anim_poster.png       a single representative frame (static fallback for PDF)

and prints the numerically measured reflection and transmission probabilities.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

plt.rcParams.update({
    "font.size": 12,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 120,
})

BLUE = "#1D4ED8"
GREEN = "#15803D"
RED = "#B91C1C"
BAR = "#9ca3af"

# ----------------------------------------------------------------------
# Physical and numerical parameters
# ----------------------------------------------------------------------
hbar = 1.0
m = 1.0

V0 = 2.0            # barrier height
bar_left, bar_right = -0.5, 0.5   # barrier from x=-0.5 to x=0.5 (width a = 1)
a = bar_right - bar_left

x0 = -40.0         # initial packet centre
sigma = 5.0        # packet width (std of |psi|^2)
k0 = 1.6           # central wavenumber; E = k0^2/2
E0 = k0**2 / (2 * m)

L = 160.0          # domain half-width: x in [-L, L]
N = 8192           # grid points
x = np.linspace(-L, L, N, endpoint=False)
dx = x[1] - x[0]

dt = 0.004
t_final = 55.0
n_steps = int(t_final / dt)

# ----------------------------------------------------------------------
# Potential, initial state, Fourier operators
# ----------------------------------------------------------------------
V = np.where((x > bar_left) & (x < bar_right), V0, 0.0)

psi = np.exp(-(x - x0) ** 2 / (4 * sigma ** 2)) * np.exp(1j * k0 * x)
psi /= np.sqrt(np.sum(np.abs(psi) ** 2) * dx)   # normalise: integral |psi|^2 dx = 1

k = 2 * np.pi * np.fft.fftfreq(N, d=dx)         # Fourier wavenumbers
kinetic_phase = np.exp(-1j * (hbar * k ** 2 / (2 * m)) * dt)   # full kinetic step
half_pot_phase = np.exp(-1j * V * dt / (2 * hbar))            # half potential step

# soft absorbing mask near the edges so nothing wraps around the periodic box
edge = 20.0
mask = np.ones_like(x)
left = x < (-L + edge)
right = x > (L - edge)
mask[left] = np.sin(np.pi / 2 * (x[left] + L) / edge) ** 0.5
mask[right] = np.sin(np.pi / 2 * (L - x[right]) / edge) ** 0.5

# ----------------------------------------------------------------------
# Time evolution (split-step Fourier), saving frames for the animation
# ----------------------------------------------------------------------
save_every = max(1, n_steps // 220)     # ~220 animation frames
frames_density = []
frames_time = []

barrier_mid = 0.0
for step in range(n_steps + 1):
    if step % save_every == 0:
        frames_density.append(np.abs(psi) ** 2)
        frames_time.append(step * dt)
    # split-step: half potential kick, full kinetic drift in Fourier space, half kick
    psi = half_pot_phase * psi
    psi = np.fft.ifft(kinetic_phase * np.fft.fft(psi))
    psi = half_pot_phase * psi
    psi *= mask

# reflection / transmission from the final density (packets are separated)
final_density = np.abs(psi) ** 2
R = np.sum(final_density[x < bar_left] ) * dx
T = np.sum(final_density[x > bar_right]) * dx
print(f"E0 = {E0:.3f},  V0 = {V0:.3f},  E0/V0 = {E0/V0:.3f}")
print(f"measured  R = {R:.3f},  T = {T:.3f},  R+T = {R+T:.3f}")

# ----------------------------------------------------------------------
# Analytic transmission coefficient for a rectangular barrier (hbar=m=1)
# ----------------------------------------------------------------------
def T_analytic(E, V0, a):
    E = np.asarray(E, dtype=float)
    out = np.empty_like(E)
    below = E < V0
    above = E > V0
    eq = ~(below | above)
    kap = np.sqrt(2 * (V0 - E[below]))
    out[below] = 1.0 / (1 + (V0 ** 2 * np.sinh(kap * a) ** 2) / (4 * E[below] * (V0 - E[below])))
    k2 = np.sqrt(2 * (E[above] - V0))
    out[above] = 1.0 / (1 + (V0 ** 2 * np.sin(k2 * a) ** 2) / (4 * E[above] * (E[above] - V0)))
    out[eq] = 1.0 / (1 + a ** 2 * V0 / 2)
    return out

# ----------------------------------------------------------------------
# Figure 1: setup
# ----------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 3.2))
ax.axvspan(bar_left, bar_right, color=BAR, alpha=0.5, label="barrier")
ax.fill_between(x, frames_density[0], color=BLUE, alpha=0.35)
ax.plot(x, frames_density[0], color=BLUE, lw=1.8, label=r"$|\psi(x,0)|^2$")
ax.plot(x, V / V0 * frames_density[0].max() * 0.9, color=BAR, lw=1.2, ls="--")
ax.set_xlim(-70, 30)
ax.set_xlabel(r"position $x$")
ax.set_ylabel(r"$|\psi|^2$")
ax.set_yticks([])
ax.set_title(rf"Initial Gaussian packet ($x_0={x0:.0f}$, $\sigma={sigma:.0f}$, $k_0={k0}$) and barrier ($V_0={V0}$)")
ax.legend(loc="upper right", frameon=False)
fig.tight_layout()
fig.savefig("figures/fig_setup.png", bbox_inches="tight")
plt.close(fig)

# ----------------------------------------------------------------------
# Figure 2: four snapshots
# ----------------------------------------------------------------------
targets = [0.0, 0.55 * t_final / 2 * 2 * 0.0 + 22.0, 33.0, t_final]
# choose four representative times robustly
snap_times = [0.0, 22.0, 33.0, t_final]
idx = [min(range(len(frames_time)), key=lambda i: abs(frames_time[i] - tt)) for tt in snap_times]
ymax = max(frames_density[0].max(), frames_density[idx[1]].max()) * 1.1

fig, axes = plt.subplots(4, 1, figsize=(8, 8), sharex=True)
labels = ["incident packet", "interacting with barrier",
          "reflected and transmitted parts separating", "final: reflected + transmitted"]
for ax, i, lab in zip(axes, idx, labels):
    ax.axvspan(bar_left, bar_right, color=BAR, alpha=0.5)
    ax.fill_between(x, frames_density[i], color=BLUE, alpha=0.35)
    ax.plot(x, frames_density[i], color=BLUE, lw=1.6)
    ax.set_ylim(0, ymax)
    ax.set_yticks([])
    ax.set_ylabel(r"$|\psi|^2$")
    ax.text(0.02, 0.82, rf"$t={frames_time[i]:.0f}$   {lab}",
            transform=ax.transAxes, fontsize=11)
axes[-1].set_xlim(-120, 90)
axes[-1].set_xlabel(r"position $x$")
axes[-1].text(0.98, 0.82, rf"$R={R:.2f}$,  $T={T:.2f}$", transform=axes[-1].transAxes,
              ha="right", fontsize=11, color=RED)
fig.suptitle("Wave-packet scattering off a rectangular barrier", y=0.995)
fig.tight_layout()
fig.savefig("figures/fig_snapshots.png", bbox_inches="tight")
plt.close(fig)

# ----------------------------------------------------------------------
# Figure 3: transmission coefficient vs energy
# ----------------------------------------------------------------------
Egrid = np.linspace(0.02, 3.0, 800) * V0
Tg = T_analytic(Egrid, V0, a)
fig, ax = plt.subplots(figsize=(8, 3.6))
ax.axvspan(0, V0, color=BAR, alpha=0.18)
ax.text(V0 * 0.5, 0.05, "classically forbidden\n(tunnelling, $E<V_0$)",
        ha="center", va="bottom", fontsize=10, color="#374151")
ax.plot(Egrid, Tg, color=GREEN, lw=2, label="analytic $T(E)$")
ax.axvline(E0, color=BLUE, ls="--", lw=1.4)
ax.plot([E0], [T], "o", color=RED, ms=7, label="packet: measured $T$")
ax.annotate(rf"packet $E={E0:.2f}$", xy=(E0, T), xytext=(E0 + 0.4, T + 0.18),
            color=BLUE, fontsize=10,
            arrowprops=dict(arrowstyle="->", color=BLUE))
ax.set_xlim(0, 3 * V0)
ax.set_ylim(0, 1.05)
ax.set_xlabel(r"incident energy $E$")
ax.set_ylabel(r"transmission $T$")
ax.set_title(r"Transmission through the barrier: nonzero even for $E<V_0$ (tunnelling)")
ax.legend(loc="lower right", frameon=False)
fig.tight_layout()
fig.savefig("figures/fig_transmission.png", bbox_inches="tight")
plt.close(fig)

# ----------------------------------------------------------------------
# Animation of |psi|^2
# ----------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 3.2))
ax.axvspan(bar_left, bar_right, color=BAR, alpha=0.5)
ax.text(0.0, ymax * 0.92, rf"$V_0={V0}$", ha="center", fontsize=10, color="#374151")
fill = ax.fill_between(x, frames_density[0], color=BLUE, alpha=0.35)
(line,) = ax.plot(x, frames_density[0], color=BLUE, lw=1.8)
time_text = ax.text(0.02, 0.85, "", transform=ax.transAxes, fontsize=11)
ax.set_xlim(-120, 90)
ax.set_ylim(0, ymax)
ax.set_yticks([])
ax.set_xlabel(r"position $x$")
ax.set_ylabel(r"$|\psi(x,t)|^2$")
ax.set_title("Time-dependent Schrodinger equation: wave packet meets a barrier")

def update(f):
    global fill
    fill.remove()
    fill = ax.fill_between(x, frames_density[f], color=BLUE, alpha=0.35)
    line.set_ydata(frames_density[f])
    time_text.set_text(rf"$t={frames_time[f]:.0f}$")
    return line, time_text

anim = FuncAnimation(fig, update, frames=len(frames_density), interval=40, blit=False)
anim.save("figures/anim.gif", writer=PillowWriter(fps=25))
plt.close(fig)

# a representative still frame (interaction moment) for the PDF fallback
poster_i = idx[1]
fig, ax = plt.subplots(figsize=(8, 3.2))
ax.axvspan(bar_left, bar_right, color=BAR, alpha=0.5)
ax.fill_between(x, frames_density[poster_i], color=BLUE, alpha=0.35)
ax.plot(x, frames_density[poster_i], color=BLUE, lw=1.8)
ax.set_xlim(-120, 90)
ax.set_ylim(0, ymax)
ax.set_yticks([])
ax.set_xlabel(r"position $x$")
ax.set_ylabel(r"$|\psi(x,t)|^2$")
ax.set_title(rf"Wave packet at the barrier ($t={frames_time[poster_i]:.0f}$)")
fig.tight_layout()
fig.savefig("figures/anim_poster.png", bbox_inches="tight")
plt.close(fig)

print("wrote figures/: fig_setup.png, fig_snapshots.png, fig_transmission.png, anim.gif, anim_poster.png")
